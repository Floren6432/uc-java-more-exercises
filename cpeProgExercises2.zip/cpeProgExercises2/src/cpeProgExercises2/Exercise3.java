package cpeProgExercises2;
import java.util.Scanner;

public class Exercise3 {

	public static void main(String[] args) {
		Scanner gimmeNum = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int num = gimmeNum.nextInt();
		
		if( num % 5 == 0) {
			System.out.println(num+ " is a multiple of 5.");
		}
		else {
			System.out.println(num+ " is not a multiple of 5.");
		}
		
		gimmeNum.close();
	}

}
