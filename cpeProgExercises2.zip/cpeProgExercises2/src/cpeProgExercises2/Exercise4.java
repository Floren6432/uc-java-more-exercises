package cpeProgExercises2;
import java.util.Scanner;

public class Exercise4 {

	public static void main(String[] args) {
		Scanner gimmeCentri = new Scanner(System.in);
		
		System.out.print("Enter a value in Degree Centrigrade: ");
		double c = gimmeCentri.nextDouble();
		
		double f = ((9 * c)/5) + 32;
		System.out.println(c+"C in Fahrenheit is: "+f);
		
		gimmeCentri.close();
	}

}
