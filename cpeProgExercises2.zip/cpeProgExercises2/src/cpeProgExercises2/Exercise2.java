package cpeProgExercises2;
import java.util.Scanner;
import java.text.DecimalFormat;

public class Exercise2 {

	public static void main(String[] args) {
		Scanner gimmeRadius = new Scanner(System.in);
		
		System.out.print("Please enter the value of radius: ");
		int radius = gimmeRadius.nextInt();
		
		double c = 2 * (Math.PI * radius);
		double area = Math.PI * (radius * radius);
		
		DecimalFormat df = new DecimalFormat();
		df.setMaximumFractionDigits(2);
		
		//System.out.println("Circumference: "+c);
		System.out.print("Circumference: ");
		System.out.println(df.format(c));
		//System.out.print("Area: "+area);
		System.out.print("Area: ");
		System.out.print(df.format(area));
		
		gimmeRadius.close();
	}

}
