package cpeProgExercises2;
import java.util.Scanner;

public class Exercise1 {
	public static void main(String[] args) {
		Scanner setOfIntegers = new Scanner(System.in);
		
		int x, num = 0, sum = 0;
		double average;
		
		System.out.print("Please enter a number for the average: ");
		int numOfAverage = setOfIntegers.nextInt();
		
		System.out.print("Please enter "+numOfAverage+" number/s: ");
		for(x=0; x<numOfAverage; x++) {
			num = setOfIntegers.nextInt();
			sum += num;
		}
		average = sum/x;
		
		System.out.println("The sum of the "+numOfAverage+" numbers are: "+sum);
		System.out.println("The average of the "+numOfAverage+" numbers are: "+average);
		
		setOfIntegers.close();
	}

}
