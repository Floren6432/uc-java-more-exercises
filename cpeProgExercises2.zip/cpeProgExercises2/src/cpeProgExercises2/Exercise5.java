package cpeProgExercises2;
import java.util.Scanner;

public class Exercise5 {

	public static void main(String[] args) {
		Scanner toBeReversed = new Scanner(System.in);
		
		System.out.print("Enter a number to be reversed: ");
		int num = toBeReversed.nextInt();
		int x = num;
		int digit = 0, re = 0;
		
		while(x!=0) {
			digit = x % 10;
			re = re * 10 + digit;
			
			x/=10;
		}
		System.out.println(num+" in reversed is "+re);
		
		toBeReversed.close();
	}

}
